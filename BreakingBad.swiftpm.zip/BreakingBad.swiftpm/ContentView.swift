import SwiftUI

struct ContentView: View {
    // Define a structure to represent questions and answer choices
    struct Question {
        let text: String
        let answers: [(text: String, character: String)]
    }

    // Define an array of questions
    let questions: [Question] = [
        Question(
            text: "What is your approach to problem-solving?",
            answers: [
                ("I prefer to plan meticulously and think several steps ahead.", "Gus Fring"),
                ("I tend to improvise and adapt to situations as they arise.", "Jesse Pinkman"),
                ("I rely on intuition and gut feelings.", "Todd Alquist"),
                ("I believe in using my intellect to outsmart my opponents.", "Heisenberg/Walter White")
            ]
        ),
        Question(
            text: "How do you handle conflicts with others?",
            answers: [
                ("I try to maintain peace and avoid confrontation.", "Skyler White"),
                ("I'm not afraid to confront others when necessary.", "Hank Schrader"),
                ("I'm willing to do whatever it takes to protect myself and my interests.", "Saul Goodman"),
                ("I prefer to resolve conflicts through diplomacy and negotiation.", "Marie Schrader")
            ]
        ),
        Question(
                           text: "What motivates you in life?",
                           answers: [
                               ("Family and personal connections.", "Jesse Pinkman"),
                               ("Ambition and the pursuit of success.", "Gustavo Fring"),
                               ("Survival and the desire for power.", "Heisenberg"),
                               ("Creativity and innovation.", "Walter White")
                           ]
                       ),
                       Question(
                           text: "How do you feel about breaking the rules to achieve your goals?",
                           answers: [
                               ("I prefer to play by the rules and maintain my integrity.", "Mike Ehrmantraut"),
                               ("Sometimes rules need to be bent for the greater good.", "Todd Alquist"),
                               ("Rules are made to be broken if it serves my interests.", "Heisenberg"),
                               ("I believe in following the rules, even if it puts me at a disadvantage.", "Skyler White")
                           ]
                       ),
                       Question(
                           text: "What role do you typically play in a group dynamic?",
                           answers: [
                               ("The peacekeeper or mediator.", "Skyler White"),
                               ("The strategist or problem solver.", "Gustavo Fring"),
                               ("The leader or the one in control.", "Heisenberg"),
                               ("The loyal supporter or advisor.", "Mike Ehrmantraut")
                           ]
                       ),
                       Question(
                           text: "What is your opinion on loyalty?",
                           answers: [
                               ("Loyalty is crucial, and I always stick by my friends and family.", "Jesse Pinkman"),
                               ("Loyalty is important, but it shouldn't come at the expense of my own interests.", "Saul Goodman"),
                               ("Loyalty is conditional, and I'll do what's necessary to protect myself.", "Mike Ehrmantraut"),
                               ("Loyalty is irrelevant; I prioritize my own goals above all else.", "Heisenberg/Walter White")
                           ]
                       ),
                       Question(
                           text: "How do you react to setbacks or failures?",
                           answers: [
                               ("I try to learn from them and move forward.", "Jesse Pinkman"),
                               ("I'm determined to overcome them, no matter what.", "Hank Schrader"),
                               ("I'll do whatever it takes to turn the situation to my advantage.", "Saul Goodman"),
                               ("I become introspective and analyze what went wrong.", "Walter White")
                           ]
                       ),
                       Question(
                           text: "What do you value most in life?",
                           answers: [
                               ("Love and personal relationships.", "Skyler White"),
                               ("Success and achievement.", "Gustavo Fring"),
                               ("Power and control.", "Heisenberg"),
                               ("Stability and security.", "Marie Schrader")
                           ]
                       ),
                       Question(
                           text: "How would you describe your moral compass?",
                           answers: [
                               ("I have a strong sense of right and wrong.", "Hank Schrader"),
                               ("I'm willing to blur the lines if it serves a greater purpose.", "Walter White"),
                               ("Morality is subjective, and I make my own rules.", "Saul Goodman"),
                               ("My moral compass is flexible, depending on the situation.", "Todd Alquist")
                           ]
                       ),
                       Question(
                           text: "What is your ultimate goal in life?",
                           answers: [
                               ("To live a peaceful and fulfilling life.", "Marie Schrader"),
                               ("To leave a lasting legacy or make a significant impact.", "Gustavo Fring"),
                               ("To be in control and have power over my own destiny.", "Heisenberg"),
                               ("To enjoy life to the fullest and experience new things.", "Jesse Pinkman")
                           ]
                       )
                   ]
        // Add other questions similarly...

    @State private var selectedAnswers: [Int?] = Array(repeating: nil, count: 10)
    @State private var isSubmitted = false

    var body: some View {
        ZStack {
            Image("Image")
                .resizable()
               // .scaledToFill()
                .edgesIgnoringSafeArea(.all)
        }
        ScrollView {
            VStack {
                ForEach(0..<questions.count) { questionIndex in
                    VStack(alignment: .leading) {
                        Text(self.questions[questionIndex].text)
                            .padding(.bottom)
                        
                        ForEach(0..<self.questions[questionIndex].answers.count) { answerIndex in
                            Button(action: {
                                self.selectedAnswers[questionIndex] = answerIndex
                            }) {
                                HStack {
                                    Image(systemName: self.selectedAnswers[questionIndex] == answerIndex ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(self.selectedAnswers[questionIndex] == answerIndex ? .blue : .gray)
                                    Text(self.questions[questionIndex].answers[answerIndex].text)
                                }
                            }
                            .padding(.bottom, 5)
                        }
                    }
                    .padding()
                }

                Button(action: {
                    self.isSubmitted.toggle()
                }) {
                    Text("Submit")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.top, 20)
                        .disabled(self.selectedAnswers.contains(nil))
                }

                if isSubmitted {
                    Text("You are most like \(calculateResult())")
                        .padding()
                }

                Spacer()

                Button(action: {
                    self.resetQuiz()
                }) {
                    Text("Reset")
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
        }
    }

    // Function to calculate the result based on selected answers
    private func calculateResult() -> String {
        var characterWeights: [String: Int] = [:]

        for questionIndex in 0..<questions.count {
            let answerIndex = selectedAnswers[questionIndex] ?? 0
            let selectedAnswer = questions[questionIndex].answers[answerIndex]
            characterWeights[selectedAnswer.character, default: 0] += 1
        }

        return characterWeights.max(by: { $0.value < $1.value })?.key ?? "Unknown"
    }

    // Function to reset the quiz
    private func resetQuiz() {
        selectedAnswers = Array(repeating: nil, count: 10)
        isSubmitted = false
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
